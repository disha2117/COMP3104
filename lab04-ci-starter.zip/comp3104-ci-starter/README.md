# COMP3104 – CI Starter

[![Build Status](https://travis-ci.com/<your-username>/<your-repo>.svg?branch=main)](https://travis-ci.com/<your-username>/<your-repo>)

Replace `<your-username>` and `<your-repo>` above after enabling Travis for this repository.

## Scripts
- `npm test` – prints a warning (no tests yet) and exits with 0 so CI passes
- `npm run build` – placeholder for your build step

## Deployed folder
Travis will deploy the contents of the `build/` directory to GitHub Pages.